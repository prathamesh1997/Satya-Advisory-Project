<!DOCTYPE html>
<html>
<head>
	<title>Satya Advisory</title>
	
</head>
<body>

<?php

 	$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
    session_start();
    
    if(isset($_POST['login']))
    {
    	$email=$_POST['vemail'];
    	$password=$_POST['vpassword'];
    	
    	$_SESSION["semail"]=$email;

    	
    	 $errorEmpty = false;
        $errorEmail = false;
        global $check_useremail;
        global $check_password;
        
        
       		 $useremail= $mysqli->real_escape_string($email);
    		$userpassword = $mysqli->real_escape_string($password);
    		
    		$select="select user_email,user_password from registration where user_email='$useremail' and user_password='$userpassword' and 
                user_status='verified'";
                
    		$result = mysqli_query($mysqli,$select);
    		
    		while($row=mysqli_fetch_assoc($result))
    		{
    			 $check_useremail=$row['user_email'];
			 $check_password=$row['user_password'];
    			
    		}
    		
    		
    		if(empty($email) || empty($password))
    		{
    			echo "<span class='form-error'>Email Id or Password is empty.</span>";
			$errorEmpty = true;
    		
    		}
    		elseif($useremail == $check_useremail && $userpassword == $check_password)
    		{
    
    			echo "<script>
    				window.location.href='http://talisman.ckwsai.in/SatayaAdvisory/home/index.php'
    			</script>";
			
    		}
    		else
    		{
    			echo "<span class='form-error'>Invalid email id or password.</span>";
			$errorEmpty = true;
    		}
     			  
    }

?>

<script >
	
	$("#vemail, #vpassword").removeClass("input-error");

	var errorEmpty = "<?php echo $errorEmpty; ?>";
	var errorEmail = "<?php echo $errorEmail; ?> ";

	if (errorEmpty == true) {

		$("#vemail,#vpassword").addClass("input-error");

	}
	
	if (errorEmail == true) {


		$("#vemail").addClass("input-error");

	}
	if (errorEmpty == false && errorEmail == false) {

		$("#vemail, #vpassword").val("");
	}

</script>
</body>
</html>