<!DOCTYPE html>
<html>
<head>
	<title>Satya Advisory</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" media="screen" href="css/index.css" />
	<!-- Material Design Bootstrap -->
 <link href="css/mdb.css" rel="stylesheet">
</head>
<body onload="myFunction()" style="margin: 0;">
<?php
    // include 'index.html';

    $servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);

    if(isset($_GET['email']) && !empty($_GET['email']))
    {
       $email = $mysqli->real_escape_string($_GET['email']);

        $search ="select user_email from registration where user_email='".$email."'";
        
        $result=$mysqli->query($search);
        
        if($result->num_rows > 0)
        {
        	mysqli_query($mysqli,"UPDATE registration SET user_status='verified' WHERE user_email='".$email."'");
        	
        	echo '<div id="load">
        	
        	</div>
        	<div style="display: none" id="myDiv" class="animate-bottom">';
			
				header("Location: http://talisman.ckwsai.in/SatayaAdvisory/index.html");
			
		'</div>        	
        	';
        	
        	
        	
		//header("Location: http://talisman.ckwsai.in/SatayaAdvisory/index.html");
		
        	
        }
        else
        {
        	 echo '<div class="">The url is either invalid or you already have activated your account</div>';
        }
    }
    else{
    // Invalid approach
    echo '<div class="">Invalid approach, please use the link that has been send to your email.</div>';
}
?>  


<script>
 
var myVar;

function myFunction() {
     myVar = setTimeout(showPage, 3000);
 }

function showPage() {
  document.getElementById("load").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

</script>


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</body>
</html>