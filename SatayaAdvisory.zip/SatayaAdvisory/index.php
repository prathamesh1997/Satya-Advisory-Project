<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Satya Advisory</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/index.css" />
    <script src="main.js"></script>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Noto+Serif" rel="stylesheet">

<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
<link rel="stylesheet" href="css/dd-testimonials.css" type="text/css">
<link rel="stylesheet" href="css/styles.css" type="text/css">
</head>
<body onload="myFunction()" style="margin: 0;" style="background-color: #e6f2ff"> 

<div id="loading"></div>

<div style="display: none" id="myDiv" class="animate-bottom">
  <div><img src="images/up.png" alt="Scrool Up" onclick="topFunction()" id="myBtn"></div>  
        <nav class="navbar navbar-dark navbar-expand-md" id="nav">
            <div class="container-fluid"><a class="navbar-brand" href="#">Home</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse"
                    id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link " href="#">About Us</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#">Services</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#">Products</a></li>
                        
                        
                    </ul >
                    <i class='fas fa-users ml-auto action-button' style="color:white; font-size: 18px;" >.

                        <a class="ml-auto action-button" data-toggle="modal" data-target="#myModal"  id="link" role="presentation" href="#">Sign In </a>
                   
                    </i>
                    
            
                </div>
            
            </div>
        </nav>
    


<div id="demo" class="carousel slide" data-ride="carousel">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/4.jpg" alt="Los Angeles" >
        <div class="carousel-caption">
          <h3 id="font"></h3>
          <p id="font">
        </p>
        </div>   
      </div>
      <div class="carousel-item">
        <img src="images/commodity.jpg" alt="Chicago" >
        <div class="carousel-caption">
          <h3 id="font"></h3>
          <p id="font">
        </p>
        </div>   
      </div>
      <div class="carousel-item">
        <img src="images/3.jpg" alt="New York">
        <div class="carousel-caption">
          <h3 id="font">New York</h3>
          <p id="font">Get the attention you deserve.</p>
        </div>   
      </div>
    </div>
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>
  <div class="container shadow-lg p-4 mb-4 bg-white">
      <div class="row">
          <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-tickers.js" async>
            {
            "symbols": [
            {
            "description": "NIFTY50",
            "proName": "NSE:NIFTY"
            },
            {
            "description": "SENSEX",
            "proName": "BSE:SENSEX"
            },
            {
            "description": "USD/INR",
            "proName": "FX_IDC:USDINR"
            },
            {
            "description": "EUR/INR",
            "proName": "FX_IDC:EURINR"
            },
            {
            "description": "Pound/INR",
            "proName": "FX_IDC:GBPINR"
            }
            ],
            "locale": "in"
           }
            </script>
      </div>
  </div>
      <br>
      <div id="">
      <div class="container text-center"><br>
      <h2 id="font" style="text-align: center;">Our Services</h2><br>
      <div class="row">
        <div class="col-sm-3 txet-center">
          <img src="images/pms.png" id="both" alt="Portfolio Management Services">
            <h5 id="font">Portfolio<br> Management Service</h5>
            <!-- <a href="#"><img src="images/read.png" alt="read"></a> -->
        </div>
        <div class="col-sm-3">
            <img src="images/equity.png" id="both" alt="Equity and Demat"><br><br>
                <h5 id="font">Equity and Demat</h5>
                <!-- <a href="#"><img src="images/read.png" alt="read"></a> -->
                
        </div>
        <div class="col-sm-3">
            <img src="images/market.jpg" id="both" alt="Market Knowledge"><br><br>
            <h5 id="font">Market Knowledge</h5>
            <!-- <a href="#"><img src="images/read.png" alt="read"></a> -->
        </div>
        <div class="col-sm-3">
            <img src="images/lead.jpg" id="both" alt="Equity,Commodity & Currency Leads">
            <h5 id="font">Equity, Commodity <br> & Currency Leads</h5>
            <!-- <a href="#"><img src="images/read.png" alt="read"></a> -->
        </div>
                    
      </div>
      
  </div><br></div>
  
  <br>
 
  <div class="shadow-lg p-4 mb-4 bg-white">
  <div class="container "> 
    <div class="row">
      <div class="col-sm-4 offset-sm-2">
        <img src="images/s1.jpg" alt="bull and bear" id="both">
      </div>
      <div class="col-sm-6 text-center" >
        <h4 id="font">What to Buy and Sell ?</h4>
        <p id="font">Get Live market leads on Equity, Commodity & Currency.</p>
        <div>
          <img src="images/Buy-Sell.gif" alt="Avatar" class="image">
            <!-- <img src="images/register.png" alt="Register " id="flex"> -->
              <br><br>
              <!-- <h5 id="font">To get Live Market Leads <br>Please Sign In.</h5> -->
              <button class="regis btn info"><span>Register</span></button>
            
          
        </div>
        <!-- <p id="font">Known For Accuracy and Consistency</p> -->
      </div>
    </div><hr>
  </div>
</div>
<!-- Testimonial Starts here -->
<div id="testBack"><br><br>
  <div class="container">
      <div class="row">
            <div class="col-sm-6">
                    <h2 id="textT">Our Testimonials</h2><br>
                    <img src="images/crm.jpg" alt="CRM" id="crm">
                    
                  </div>
        <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3" role="tabpanel">
          <div class="col-xs-4 col-sm-12">
              <!-- Nav tabs --><br>
              <ul class="nav nav-justified" id="nav-tabs" role="tablist">
                  <li role="presentation" class="active">
                      <a href="#dustin" aria-controls="dustin" role="tab" data-toggle="tab">
                          <img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/dustinlamont/128.jpg" />
                          <span class="quote"><i class="fa fa-quote-left"></i></span>
                      </a>
                  </li>
                  <li role="presentation" class="">
                      <a href="#daksh" aria-controls="daksh" role="tab" data-toggle="tab">
                          <img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/dakshbhagya/128.jpg" />
                          <span class="quote"><i class="fa fa-quote-left"></i></span>
                      </a>
                  </li>
                  <li role="presentation" class="">
                      <a href="#anna" aria-controls="anna" role="tab" data-toggle="tab">
                          <img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/annapickard/128.jpg" />
                          <span class="quote"><i class="fa fa-quote-left"></i></span>
                      </a>
                  </li>
                  <li role="presentation" class="">
                      <a href="#wafer" aria-controls="wafer" role="tab" data-toggle="tab">
                          <img class="img-circle" src="https://s3.amazonaws.com/uifaces/faces/twitter/waferbaby/128.jpg" />
                          <span class="quote"><i class="fa fa-quote-left"></i></span>
                      </a>
                  </li>
              </ul>
          </div>
          <div class="col-xs-8 col-sm-12">
              <!-- Tab panes -->
              <div class="tab-content" id="tabs-collapse">            
                  <div role="tabpanel" class="tab-pane fade in active" id="dustin">
                      <div class="tab-inner">                    
                          <p class="lead" id="textT"> Etiam tincidunt enim et pretium efficitur. Donec auctor leo sollicitudin eros iaculis sollicitudin.</p>
                          <hr>
                          <p><strong class="text-uppercase" id="textT">Dustin Lamont</strong></p>
                          <p><em class="text-capitalize" id="textT"> Senior web developer</em> at <a href="#" >Apple</a></p>                 
                      </div>
                  </div>
                  
                  <div role="tabpanel" class="tab-pane fade" id="daksh">
                      <div class="tab-inner">
                          <p class="lead" id="textT">Suspendisse dictum gravida est, nec consequat tortor venenatis a. Suspendisse vitae venenatis sapien.</p>
                          <hr>
                          <p><strong class="text-uppercase" id="textT">Daksh Bhagya</strong></p>
                          <p><em class="text-capitalize" id="textT"> UX designer</em> at <a href="#">Google</a></p>
                      </div>
                  </div>
                  
                  <div role="tabpanel" class="tab-pane fade" id="anna">
                      <div class="tab-inner">
                          <p class="lead" id="textT">Nullam suscipit ante ac arcu placerat, nec sagittis quam volutpat. Vestibulum aliquam facilisis velit ut ultrices.</p>
                          <hr>
                          <p><strong class="text-uppercase" id="textT">Anna Pickard</strong></p>
                          <p><em class="text-capitalize" id="textT"> Master web developer</em> at <a href="#">Intel</a></p>
                      </div> 
                  </div>
                  
                  <div role="tabpanel" class="tab-pane fade" id="wafer">
                      <div class="tab-inner">
                          <p class="lead" id="textT"> Fusce erat libero, fermentum quis sollicitudin id, venenatis nec felis. Morbi sollicitudin gravida finibus.</p>
                          <hr>
                          <p><strong class="text-uppercase" id="textT"> Wafer Baby</strong></p>
                          <p><em class="text-capitalize" id="textT"> Web designer</em> at <a href="#">Microsoft</a></p>
                      </div>
                  </div>
              </div>
          </div>        
      </div>
          
      </div>
      <div class="row" style="background-color: #4da6ff">
          
      </div>
  </div>
</div>



<!-- Contact fixed left form -->
<div>
  <img src="images/contact.jpg" alt="Contact US form" class="open-button" onclick="openForm()" style="width:10%; height: auto">
  <div class="chat-popup" id="myForm">
    <form action="/action_page.php" class="form-container">
      <!-- <img src="images/login3.png" alt="Contact US " style="width:20%; "> -->
      <h5 id="font">Write Your Query.</h5><br>
      <!-- <label for="email"><b>Email *</b></label> -->
      <div class="form-group">
      <input type="email" class="form-control" placeholder="Enter email" required>
    </div>
    <div class="form-group">
      <input type="text" class="form-control" placeholder="Contact Number" required>
    </div>
    
    <div class="form-group">
      <!-- <label for="msg"><b>Message</b></label> -->
      <textarea placeholder="Type message.." rows="6" cols="4" name="msg" class="form-control" required></textarea>
    </div>
    <div class="form-group">
      <button type="submit" class="btn btn-outline-info">Send</button>
      <button type="button" class="btn btn-outline-danger" onclick="closeForm()">Close</button>
    </div>
    </form>
  </div>

</div>
</div>
<!-- End of Animation -->



  <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header
        <div class="modal-header">
          <h4 class="modal-title" id="font">Registration details</h4>
          
        </div> -->
        
        <!-- Modal body -->
        <div class="modal-body" >
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            <!-- Nav tabs -->
            <ul class="nav nav-tabs justify-content-center" role="tablist"  >
                <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#home" id="font">Sign In</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#menu1" id="font">New User ?</a>
                </li>
                <!-- <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#menu2">Menu 2</a>
                </li> -->
            </ul>
            <!-- Tab panes -->
  <div class="tab-content">
        <div id="home" class="container tab-pane active"><br>
            
           
        </div>
        <div id="menu1" class="container tab-pane fade"><br>
            
           
        </div>
        
      </div>
        </div>
        
        <!-- Modal footer
        <div class="modal-footer">
          <button type="button" class="btn btn-warningx" data-dismiss="modal">Close</button>
        </div> -->
        
      </div>
    </div>
  </div>

<script>
 
var myVar;

function myFunction() {
     myVar = setTimeout(showPage, 3000);
 }

function showPage() {
  document.getElementById("loading").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<!-- Scroll Up -->
<script>
  // When the user scrolls down 20px from the top of the document, show the button
  window.onscroll = function() {scrollFunction()};
  
  function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          document.getElementById("myBtn").style.display = "block";
      } else {
          document.getElementById("myBtn").style.display = "none";
      }
  }
  
  // When the user clicks on the button, scroll to the top of the document
  function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
  }
  </script>


<!-- Scroll Up ends -->
<!-- fixed contact form -->
<script>
  function openForm() {
      document.getElementById("myForm").style.display = "block";
  }
  
  function closeForm() {
      document.getElementById("myForm").style.display = "none";
  }
  </script>
<!-- end of contact  -->
</body>
</html>