<?php

   
    $servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
    session_start();
    global $c_id;
    if(isset($_POST['update']))
    {
        $e_name=$_POST['e_name'];
        $e_buy=$_POST['e_buy'];
        $e_sell=$_POST['e_sell'];
        $e_description=$_POST['e_description'];
        $e_date=$_POST['e_date'];
        
	
	
	
        $errorEmpty = false;
        $errorEmail = false;
    
    		
			
			
    		    
        if (empty($e_name) || empty($e_buy) || empty($e_sell) || empty($e_description) || empty($e_date) ) {
			echo "<span class='form-error'> Check for proper Input.</span>";
			$errorEmpty = true;
        }
      
        
        else {
           		
           		$equity_name= $mysqli->real_escape_string($e_name);
	    		$equity_buy= $mysqli->real_escape_string($e_buy);
		        $equity_sell=$mysqli->real_escape_string($e_sell);
			$equity_description=$mysqli->real_escape_string($e_description);
			$equity_date=$mysqli->real_escape_string($e_date);	
            
            $sql = "insert into Equity(e_name,e_buy,e_sell,e_description,e_date) values 
                  ('$equity_name','$equity_buy','$equity_sell','$equity_description','$equity_date')";	
                
                
                if ($mysqli->query($sql) === true) {
			
			$comment="select * from Equity order by e_id desc limit 1";
			$res=mysqli_query($mysqli,$comment);
			while($row=$res->fetch_assoc())
		   			{
		   			
		   				$c_id=$row['e_id'];	
		   			}
		   			
		   			$c_name="SatyaAdvisory";
		   			$c_content="Welcome,Start your discussion";
		   			
		   			 $sqlite = "insert into comment(comment_id,comment_name,comment_content) values 
               				   ('$c_id','$c_name','$c_content')";	
                
		   			if($mysqli->query($sqlite) === true)
		   			{		
			
                 				 echo "<span class='form-success'>Records updated successfully.</span>";
                 			 }
                 		
			

           
            }
            else
		{
			echo "<span class='form-error'> Error Inserting Records.</span>";
			$errorEmpty = true;
		}
                  
                  	
		}
		
        
    }
    else
	{
		echo "There was an error";
	}

?>

<script >
	
	$("#e_name, #e_buy, #e_sell, #e_description, #e_date").removeClass("input-error");

	var errorEmpty = "<?php echo $errorEmpty; ?>";
	var errorEmail = "<?php echo $errorEmail; ?> ";

	if (errorEmpty == true) {

		$("#e_name, #e_buy, #e_sell, #e_description, #e_date").addClass("input-error");

	}
	
	if (errorEmail == true) {


		$("#e_name").addClass("input-error");

	}
	if (errorEmpty == false && errorEmail == false) {

		$("#e_name, #e_buy, #e_sell, #e_description, #e_date").val("");
	}

</script>






