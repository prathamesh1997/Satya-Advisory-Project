<!DOCTYPE html>
<html>
<head>
	<title>Satya Advisory</title>
	
</head>
<body>

<?php

 	$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
    session_start();
    
    if(isset($_POST['login']))
    {
    	$admin_name=$_POST['admin_name'];
    	$admin_password=$_POST['admin_password'];
    	
    	$_SESSION["admin_name"]=$admin_name;

    	
    	 $errorEmpty = false;
        $errorEmail = false;
        global $check_adminname;
        global $check_adminpassword;
        
        
       		 $admin_name= $mysqli->real_escape_string($admin_name);
    		$admin_password = $mysqli->real_escape_string($admin_password);
    		
    		$select="select admin_name,admin_password from Admin where admin_name='$admin_name' and admin_password='$admin_password'";
                
    		$result = mysqli_query($mysqli,$select);
    		
    		while($row=mysqli_fetch_assoc($result))
    		{
    			 $check_adminname=$row['admin_name'];
			 $check_adminpassword=$row['admin_password'];
    			
    		}
    		
    		
    		if(empty($admin_name) || empty($admin_password))
    		{
    			echo "<div class='alert alert-danger' role='alert'>
 				 Email Id or password is empty
			</div>";
			$errorEmpty = true;
    		
    		}
    		elseif($admin_name == $check_adminname && $admin_password == $check_adminpassword)
    		{
    			echo "<script>
    				window.location.href='http://talisman.ckwsai.in/SatayaAdvisory/home/Admin/admin.php'
    			</script>";
    			
			
    		}
    		else
    		{
    			echo "<div class='alert alert-danger' role='alert'>
 				Invalid Email id or password
			</div>";
			$errorEmpty = true;
    		}
     			  
    }

?>

<script >
	
	$("#admin_name, #admin_password").removeClass("input-error");

	var errorEmpty = "<?php echo $errorEmpty; ?>";
	var errorEmail = "<?php echo $errorEmail; ?> ";

	if (errorEmpty == true) {

		$("#admin_name,#admin_password").addClass("input-error");

	}
	
	if (errorEmail == true) {


		$("#admin_name").addClass("input-error");

	}
	if (errorEmpty == false && errorEmail == false) {

		$("#admin_name, #admin_password").val("");
	}

</script>
</body>
</html>