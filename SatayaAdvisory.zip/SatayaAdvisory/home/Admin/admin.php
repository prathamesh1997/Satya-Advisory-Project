<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css?family=Noto+Serif" rel="stylesheet">
	<link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
	<link rel="stylesheet" href="css/index.css"> 
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
	<link rel="stylesheet" href="css/styles.css">
  	<link rel="stylesheet" href="css/mdb.css"> 
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<title>Sataya Advisory</title>
	
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
</head>
<body onload="myFunction()"  style="margin: 0;" >

<?php

	session_start();
	
	
	if(!isset($_SESSION['admin_name']) || $_SESSION['admin_name'] == '')
	{
		echo "<script>
    				window.location.href='http://talisman.ckwsai.in/SatayaAdvisory/error/index.html'
    			</script>";
	}
	
	
	
	$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
        $sql = "SELECT r_id FROM registration";
	$result = $mysqli->query($sql);
	
	$count=mysqli_num_rows($result);
    
?>
<div id="loading"></div>

<div style="display: none" id="myDiv" class="animate-bottom">
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'qVd97D57lq';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
<!-- {/literal} END JIVOSITE CODE -->
	<header class="cd-main-header">
		<a href="#0" class="cd-logo"><img src="img/cd-logo.svg" alt="Logo"></a>
<!-- 		
		<div class=" is-hidden">
			<form action="#0">
				<input type="search" placeholder="Search...">
			</form>
		</div>  -->

		<a href="#0" class="cd-nav-trigger">Menu<span></span></a>

		<nav class="cd-nav">
			<ul class="cd-top-nav">
				<!-- <li><a href="#0">Tour</a></li>
				<li><a href="#0">Support</a></li> -->
				<li class="has-children account">
					<a href="#0">
						<img src="img/login3.png" alt="avatar">
						<?= $_SESSION['admin_name']; ?>
					</a>

					<ul>

						<!--<li><a href="#0">My Account</a></li>
						<li><a href="#0">Edit Account</a></li>-->
						
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>
	</header> <!-- .cd-main-header -->

	<main class="cd-main-content">
		<nav class="cd-side-nav">
			<ul>
				<li class="cd-label">Main</li>
				<li class="has-children overview">
					<a href="#0">Overview</a>
					
					<ul>
						<li><a href="#0">All Data</a></li>
						<li><a href="#0">Category 1</a></li>
						<li><a href="#0">Category 2</a></li>
					</ul>
				</li>
				<li class="has-children notifications active">
					<a href="#0">Market Leads <!--<span class="count"></span>--></a>
					
					<ul>
						<li><a data-toggle="tab" href="#equity" >Equity</a></li>
						<li><a data-toggle="tab" href="#menu1">Commodity</a></li>
						<li><a href="#0">Currency</a></li>
					</ul>
				</li>

				<!-- <li class="has-children comments">
					<a href="#0">Comments</a>
					
					<ul>
						<li><a href="#0">All Comments</a></li>
						<li><a href="#0">Edit Comment</a></li>
						<li><a href="#0">Delete Comment</a></li>
					</ul>
				</li> -->
			</ul>

			<ul>
				<li class="cd-label">Secondary</li>
				<li class="has-children bookmarks">
					<a href="#0">Our Services</a>
					
					<ul>
						<li><a href="#0">Portfolio Management Service</a></li>
						<li><a href="#0">Equity and Demat</a></li>
						<li><a href="#0">Market Knowledge</a></li>
					</ul>
				</li>
				<li class="has-children images">
					<a href="#0">Images</a>
					
					<ul>
						<li><a href="#0">All Images</a></li>
						<li><a href="#0">Edit Image</a></li>
					</ul>
				</li>

				
			</ul>

			<ul>
				<li class="cd-label">Action</li>
				<li class="action-btn"><a href="logout.php">Logout</a></li>
			</ul>
		</nav>

		<div class="content-wrapper"><br>
		<div class="container">
		<div class="row">
			<div class="col-sm-4">
				<!-- Card Wider -->
		<div class="card card-cascade wider">
		
		  <!-- Card image -->
		  <div class="view view-cascade overlay"><br>
		  <img  class="card-img-top" src="img/Visitors.jpeg" alt="Card image cap">
		    
		    <a href="#!">
		      <div class="mask rgba-white-slight"></div>
		    </a>
		  </div>
		
		  <!-- Card content -->
		  <div class="card-body card-body-cascade text-center">
			<h3 id="font">Count <?= $count ?></h3>
		    <!-- Title -->
		    <h4  class="card-title"><strong>People Registered </strong></h4>
		    <!-- Subtitle -->
		    
		    <!-- Text -->
		   
			<button type="button" class="btn btn-primary btn-lg">View Data</button>
		  
		  </div>
		
		</div>
		
		<!-- Card Wider -->
			</div>
				<div class="col-sm-4">
				<!-- Card Wider -->
		<div class="card card-cascade wider">
		
		  <!-- Card image -->
		  <div class="view view-cascade overlay"><br>
		  <img  class="card-img-top"  src="img/EquityUpdate.jpeg" alt="Card image cap">
		    
		    <a href="#!">
		      <div class="mask rgba-white-slight"></div>
		    </a>
		  </div>
		
		  <!-- Card content -->
		  <div class="card-body card-body-cascade text-center">
			
		    <!-- Title -->
		    <h4  class="card-title" id="font">Equity Updates</h4>
		    <!-- Subtitle -->
		    <h5 class="blue-text pb-2"><strong>Share Market</strong></h5>
		    <!-- Text -->
		   
			<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modalLoginForm">Update</button>
		  
		  </div>
		
		</div>
		<!-- Card Wider -->
			</div>
		
		
				<div class="col-sm-4">
				<!-- Card Wider -->
		<div class="card card-cascade wider">
		
		  <!-- Card image -->
		  <div class="view view-cascade overlay"><br>
		  <img  class="card-img-top" src="img/rupee.jpeg" alt="Card image cap">
		    
		    <a href="#!">
		      <div class="mask rgba-white-slight"></div>
		    </a>
		  </div>
		
		  <!-- Card content -->
		  <div class="card-body card-body-cascade text-center">
			
		    <!-- Title -->
		    <h4  class="card-title" id="font">Currency Updates</h4>
		    <!-- Subtitle -->
		    <h5 class="blue-text pb-2"><strong>Share Market</strong></h5>
		    <!-- Text -->
		   
			<button type="button" class="btn btn-primary btn-lg">Update</button>
		  
		  </div>
		
		</div>
		<!-- Card Wider -->
			</div>
		</div>
		<div class="row"> 
			<div class="col-sm-8">
				<div id="users-details">
					<div class="table-responsive text-nowrap" id="inputGroupMaterial-sizing-lg">
						<div class="table-responsive text-nowrap">

						  <table class="table">
						    <thead>
						      <tr>
						        <th scope="col">#</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						        <th scope="col">Heading</th>
						      </tr>
						    </thead>
						    <tbody>
						      <tr>
						        <th scope="row">1</th>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						      </tr>
						      <tr>
						        <th scope="row">2</th>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						      </tr>
						      <tr>
						        <th scope="row">3</th>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						        <td>Cell</td>
						      </tr>
						    </tbody>
						  </table>
						
						</div>
  						
						  				

					</div>
				</div>
			</div>
		</div>
		</div>
		</div> <!-- .content-wrapper -->
	</main> <!-- .cd-main-content -->
	
	<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
	  aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header text-center">
	        <h4 class="modal-title w-100 " id="font">Equity Leads</h4>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body mx-3">
	        <div class="md-form mb-5">
        <form action="equityinput.php" method="post">
        <h6 class="form-message"></h6>
        	<div class="md-form input-group input-group-lg">
	  <div class="input-group-prepend">
	    <span class="input-group-text md-addon" id="">Stock Name</span>
	  </div>
	  <textarea class="md-textarea form-control" aria-label="With textarea" id="e_name"></textarea>
	</div>
	
          <div class="md-form input-group input-group-lg">
	  <div class="input-group-prepend">
	    <span class="input-group-text md-addon" id="inputGroupMaterial-sizing-lg">Buy and Sell</span>
	  </div>
	  <input type="text" aria-label="First name" class="form-control" placeholder="Buy Price" id="e_buy">
	  <input type="text" aria-label="Last name" class="form-control" placeholder="Sell Price" id="e_sell">
	</div>
        </div>

       <div class="md-form input-group input-group-lg">
	  <div class="input-group-prepend">
	    <span class="input-group-text md-addon" id="inputGroupMaterial-sizing-lg">Description</span>
	  </div>
	  <textarea class="md-textarea form-control" aria-label="With textarea" id="e_description"></textarea>
	</div>
	
	<div class="md-form input-group input-group-lg">
	     <div class="input-group-prepend">
	    	 <span class="input-group-text md-addon" id="inputGroupMaterial-sizing-lg">Date and Time</span>
	    </div>
	  
	    <input class="form-control" type="datetime-local" value="Select Date and time" id="e_date" >
	 
	</div>
	<button type="submit" id="update" class="btn btn-purple btn-lg">Update</button>
	<br>
	</form>
      </div>
      
    </div>
  </div>
	
</div>

</div>
<script>
 
var myVar;

function myFunction() {
     myVar = setTimeout(showPage, 3000);
 }

function showPage() {
  document.getElementById("loading").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
<script>
    $(document).ready(function(){

        $("form").submit(function(event){
        event.preventDefault();

        var e_name=$("#e_name").val();
        var e_buy=$("#e_buy").val();
        var e_sell=$("#e_sell").val();
        var e_description=$("#e_description").val();
        var e_date=$("#e_date").val();
        
	var update= $("#update").val();

        $(".form-message").load("equityinput.php",{
            e_name: e_name,
            e_buy: e_buy,
            e_sell: e_sell,
            e_description: e_description,
            e_date: e_date,
            update: update
        });
    });
    });
</script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="js/jquery-2.1.4.js"></script>
<script src="js/jquery.menu-aim.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</body>
</html>