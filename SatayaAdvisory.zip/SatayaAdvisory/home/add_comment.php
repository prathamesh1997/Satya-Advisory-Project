<!DOCTYPE html>
<html>
<head>
	<title>Satya Advisory</title>
	
</head>
<body
<?php	
session_start();
	$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	
	$mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
   
     if(isset($_POST['submit']))
    {
	$comment_name=$_POST['comment_name'];
    	$comment_id=$_POST['comment_id'];
    	$comment_content=$_POST['comment_content'];
    	
    	 $errorEmpty = false;
         $errorEmail = false;
        
        	$comment_name= $mysqli->real_escape_string($comment_name);
    		$comment_id= $mysqli->real_escape_string($comment_id);
    		$comment_content=$mysqli->real_escape_string($comment_content);
    		
    		if(empty($comment_name) || empty($comment_id) || empty($comment_content))
    		{
    			echo '<p>Comment is necesssary</p>';
    			$errorEmpty= true;
    		}
    		else
    		{
    				 $sql = "insert into comment (comment_id,comment_name,comment_content) values 
                  			('$comment_id','$comment_name','$comment_content')";	
                  			
                  			
                		 if ($mysqli->query($sql) === true) {
                		 
                		 	$comment="select * from comment where comment_id='".$comment_id."' order by date desc";
    					$res=mysqli_query($mysqli,$comment);
						while($raw=$res->fetch_assoc())
		   			{
		   			
		   				$raws[]=$raw;
		   			}
		   			foreach($raws as $pro)
					{
						$mystr=$pro['comment_name'];
						$gotit=substr($mystr,0,8);
                			
                			echo'
                			
                				<section class="my-5">

						  <!-- Grid row -->
						  <div class="row">
						
						    <!-- Grid column -->
						    <div class="col-md-12">
						    		<div class="media border p-3">
								    <img src="img/user.svg" alt="John Doe" class="mr-3 mt-3 rounded-circle" style="width:6%;">
								    <div class="media-body">
								      <h4>'.$gotit.' <small><i>'.$pro['date'].'</i></small></h4>
								      <p>'.$pro['comment_content'].'</p>      
								    </div>
								  </div>
						    </div>
						   </div>
					</section>
                			';
                			}
                			
                		 }
                		 else
                		 {
                		 	echo '<p>error adding the comment</p>';
                		 	$errorEmpty= true;
                		 }

    		}
	
    }
	
	
	
?>
<script >
	
	var errorEmpty = "<?php echo $errorEmpty; ?>";
	if (errorEmpty == false ) {

		$("#comment_content").val("");
	}

</script>
</body>
</body>
</html>
