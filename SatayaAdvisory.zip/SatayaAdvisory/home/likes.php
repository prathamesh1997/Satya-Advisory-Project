<?php

$servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	global $display_likes;
	  $mysqli= mysqli_connect($servername,$username , $password,$dbname);
	  
	  
	  if(isset($_POST['likes']))
	{
		$e_id=$_POST['e_id'];	
		$e_likes=$_POST['e_likes'];
		
		$update="UPDATE Equity set likes = '".$e_likes."'+1 where e_id = '".$e_id."' ";
		
		if ($mysqli->query($update) === TRUE) {
		   
		   	$select="Select * from Equity where e_id = '".$e_id."'";
		   	
		   	$result=$mysqli->query($select);
		   	if($result->num_rows > 0)
		   	{
		   		while($row = $result->fetch_assoc())
		   		{
		   			echo '<p>'.$row["likes"].'</p>';
		   		}
		   	}
		   	
		   	
		}
	}  

	

?>