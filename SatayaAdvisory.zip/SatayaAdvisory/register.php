<!DOCTYPE html>
<html>
<head>
	<title>Satya Advisory</title>
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;" />
   
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/mdb.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>
<body  >

<?php

    require 'phpmailer/PHPMailerAutoload.php';

    $servername = "localhost";
	$username = "talisman2018";
	$password = "ISHWARi@123";
	$dbname = "SatyaAdvisory";
	// Create connection
    $mysqli= mysqli_connect($servername,$username , $password,$dbname);
    
    session_start();
    
    if(isset($_POST['submit']))
    {
        $email=$_POST['email'];
        $number=$_POST['number'];
        $password=$_POST['password'];
        $Cpassword=$_POST['Cpassword'];
        $user_date= date("Y/m/d") ;
	
	
	
        $errorEmpty = false;
        $errorEmail = false;
    
    		$useremail= $mysqli->real_escape_string($email);
    		$usernumber= $mysqli->real_escape_string($number);
			
			$select="select r_id from registration where user_email='$useremail' and user_number='$usernumber'";
			
			$result = mysqli_query($mysqli,$select);
			 $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
     			
     			  $count = mysqli_num_rows($result);
     			  
		  if($count == 1)
		  {
		  	echo "<div class='alert alert-danger' role='alert'>
				 Email Id or Number already exist
				</div><button type='button' class='close' data-dismiss='alert' aria-label='Close'>
				    <span aria-hidden='true'>&times;</span>
				  </button>";
			$errorEmpty = true;
		  }
    		
    	else
    	{		
    		
    		    
        if (empty($email) || empty($number) || empty($password) || empty($Cpassword) || $password != $Cpassword) {
			echo "<span class='form-error'> Check for proper Input.</span>";
			$errorEmpty = true;
        }
       elseif(strlen($password)<=5)
       {
       		echo "<div class='alert alert-danger' role='alert'>Password size should be more than 5 digits.</div>";
			$errorEmpty = true;
       }
        elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<span class='form-error'>WRITE A VALID EMAIL ADDRESS</span>";
			$errorEmail = true;
        }
        else {
           		 $email= $mysqli->real_escape_string($email);
		    $number= $mysqli->real_escape_string($number);
            		$password= $mysqli->real_escape_string($password);
            
            $sql = "insert into registration (user_email,user_number,user_password,user_date) values 
                  ('$email','$number','$password','$user_date')";	
                
                
                if ($mysqli->query($sql) === true) {

                    $base_url="http://talisman.ckwsai.in/SatayaAdvisory/";
                    $emailuser="prathameshsawant97@gmail.com";
                    $password="ISHWARi@123";

                    $to = $emailuser;
		//	$message="Hello Thanks for getting register, You are few steps away from getting verified \n Please 
			//click on the link below to verify yourself.";
			$message="
			
				<div class='container'>
					<div class='col-sm-6 offset-md-3 text-center' >
						<div class='shadow-lg p-4 mb-4 bg-white'>
							<img src='images/1icon.PNG' alt='Send Email' width='100%' height='auto'>
							<p style='text-align: center; color: #00008B;font-family: times new roman'>Hi,".$email."</p>
							<p style='text-align: center; color: #00008B;font-family: times new roman'>Thank You.</p>
							<img src='images/01.gif' alt='Send Email' width='50%' height='auto'>
						<a href='".$base_url."email_verification.php?email=".$email."' style='text-align: center; color: #00008B;font-family: times new 
                                               roman' >Please Click on these link to Proceed.</a>
						</div>
					</div>	
				</div>
			";

			$subject="Email Verificaiton Link Satya Advisory";
			
			//configure smtp server settings
			
			$mail= new PHPMailer;
			//mail->isSMTP();
			$mail->Host='smtp.gmail.com';
			$mail->port=587;
			$mail->SMTPSecure='ssl';
			$mail->SMTPAuth=true;
			$mail->Username=$emailuser;
			$mail->password=$password;
			
			//email sending details
			$mail->addAddress($to);
			$mail->Subject=$subject;
			$mail->msgHTML($message);

            if(!$mail->send())
			{
				echo "<span class='form-error'>Message Could Not be sent</span>";
				echo 'Mailer Error'.$email->ErrorInfo;
				
			}
			else
			{
				echo "<div  class='alert alert-success' role='alert'>Registration Successfull <br>Please check your email to verify yourself.</div>";
	
			}

            }
            else
		{
			$message='Error in inserting records';
		}
                  
                  	
		}
		}	
        
    }
    else
	{
		echo "There was an error";
	}

?>

<script >
	
	$("#email, #number, #password").removeClass("input-error");

	var errorEmpty = "<?php echo $errorEmpty; ?>";
	var errorEmail = "<?php echo $errorEmail; ?> ";

	if (errorEmpty == true) {

		$("#email, #number, #password").addClass("input-error");

	}
	
	if (errorEmail == true) {


		$("#email").addClass("input-error");

	}
	if (errorEmpty == false && errorEmail == false) {

		$("#email, #number, #password,#Cpassword").val("");
	}

</script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

</body>
</html>




